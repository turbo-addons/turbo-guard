/**
 * Turbo Guard Admin JavaScript.
 *
 * @package TurboGuard
 * @since 1.0.0
 */

(function ($) {
	'use strict';

	var TurboGuard = {

		/**
		 * Initialize.
		 */
		init: function () {
			this.bindEvents();
			this.updateSelectionCount();
			this.init2fa();
		},

		/**
		 * Bind event handlers.
		 */
		bindEvents: function () {
			// Scanner page.
			$( '#turbo-guard-start-scan' ).on( 'click', $.proxy( this.startScan, this ) );
			$( '#turbo-guard-select-all' ).on( 'change', $.proxy( this.toggleSelectAll, this ) );
			$( '#turbo-guard-select-critical' ).on( 'click', $.proxy( this.selectCritical, this ) );
			$( '#turbo-guard-delete-selected' ).on( 'click', $.proxy( this.deleteSelected, this ) );
			$( '#turbo-guard-quarantine-selected' ).on( 'click', $.proxy( this.quarantineSelected, this ) );
			$( document ).on( 'click', '.turbo-guard-delete-single', $.proxy( this.deleteSingle, this ) );
			$( document ).on( 'click', '.turbo-guard-quarantine-single', $.proxy( this.quarantineSingle, this ) );
			$( document ).on( 'click', '.turbo-guard-ignore-single', $.proxy( this.ignoreSingle, this ) );
			$( document ).on( 'click', '.turbo-guard-mark-fixed-single', $.proxy( this.markFixed, this ) );
			$( document ).on( 'click', '.turbo-guard-delete-post', $.proxy( this.deletePost, this ) );
			$( document ).on( 'change', '.turbo-guard-file-check', $.proxy( this.updateSelectionCount, this ) );

			// Settings page.
			$( '#turbo-guard-settings-form' ).on( 'submit', $.proxy( this.saveSettings, this ) );

			// Settings: Two-Factor Authentication setup.
			$( '#turbo-guard-2fa-enable' ).on( 'click', $.proxy( this.enable2fa, this ) );
			$( '#turbo-guard-2fa-disable' ).on( 'click', $.proxy( this.disable2fa, this ) );
			$( '#turbo-guard-2fa-regen' ).on( 'click', $.proxy( this.regenerate2fa, this ) );

			// Firewall: block IP from form.
			$( '#turbo-guard-block-ip-form' ).on( 'submit', $.proxy( this.blockIp, this ) );

			// Firewall: rate limiting settings.
			$( '#turbo-guard-rate-limit-form' ).on( 'submit', $.proxy( this.saveRateLimits, this ) );

			// Firewall: rate limiting toggle show/hide the limit fields.
			this.toggleRateLimitFields();
			$( '#turbo-guard-rate-limit-enabled' ).on( 'change', $.proxy( this.onRateLimitToggle, this ) );

			// Firewall: unblock IP button.
			$( document ).on( 'click', '.turbo-guard-unblock-ip', $.proxy( this.unblockIp, this ) );

			// Firewall: block from log button.
			$( document ).on(
				'click',
				'.turbo-guard-block-from-log',
				function () {
					var ip = $( this ).data( 'ip' );
					$( '#turbo-guard-block-ip-input' ).val( ip );
					$( '#turbo-guard-block-ip-form' ).trigger( 'submit' );
				}
			);
		},

		// =========================================================
		// SCANNER
		// =========================================================

		/**
		 * Start malware scan.
		 */
		startScan: function (e) {
			e.preventDefault();

			var self = this;
			var $btn = $( '#turbo-guard-start-scan' );

			$btn.prop( 'disabled', true ).html( '<span class="dashicons dashicons-update-alt" style="animation:rotation 1s infinite linear;vertical-align:middle;"></span> Scanning...' );
			$( '#turbo-guard-scan-progress' ).show();
			$( '#turbo-guard-progress-label' ).text( 'Starting scan...' );

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action: 'turbo_guard_start_scan',
						nonce:  turboGuardAdmin.nonce
					},
					success: function (response) {
						if (response.success) {
							self.continueScan( response.data.scan_id, 0 );
						} else {
							alert( 'Error: ' + (response.data ? response.data.message : 'Failed to start scan') );
							$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-search"></span> Start Full Scan' );
							$( '#turbo-guard-scan-progress' ).hide();
						}
					},
					error: function (xhr) {
						alert( 'AJAX error starting scan. Status: ' + xhr.status );
						$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-search"></span> Start Full Scan' );
						$( '#turbo-guard-scan-progress' ).hide();
					}
				}
			);
		},

		/**
		 * Continue scanning in chunks.
		 */
		continueScan: function (scanId, offset) {
			var self = this;

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:  'turbo_guard_scan_chunk',
						nonce:   turboGuardAdmin.nonce,
						scan_id: scanId,
						offset:  offset
					},
					success: function (response) {
						if ( ! response.success) {
							alert( 'Scan chunk error: ' + (response.data ? response.data.message : 'Unknown') );
							location.reload();
							return;
						}

						var data = response.data;

						// Update progress bar.
						$( '#turbo-guard-progress-fill' ).css( 'width', data.percent + '%' );
						$( '#turbo-guard-progress-count' ).text( data.scanned + ' / ' + data.total + ' files' );
						$( '#turbo-guard-progress-label' ).text(
							data.percent + '% scanned' + (data.new_threats > 0 ? ' — ' + data.new_threats + ' threat(s) found' : '')
						);

						if (data.done) {
							$( '#turbo-guard-progress-label' ).text( 'Scan Complete! Reloading...' );
							setTimeout(
								function () {
									location.reload();
								},
								1200
							);
						} else {
							// Small delay to avoid hammering server.
							setTimeout(
								function () {
									self.continueScan( scanId, data.next_offset );
								},
								100
							);
						}
					},
					error: function (xhr) {
						alert( 'Scan error at offset ' + offset + '. Status: ' + xhr.status + '. The scan may have partially completed — refresh the page.' );
						location.reload();
					}
				}
			);
		},

		/**
		 * Toggle select all checkboxes.
		 */
		toggleSelectAll: function () {
			var checked = $( '#turbo-guard-select-all' ).is( ':checked' );
			$( '.turbo-guard-file-check' ).prop( 'checked', checked );
			this.updateSelectionCount();
		},

		/**
		 * Select only critical severity files.
		 */
		selectCritical: function () {
			$( '.turbo-guard-file-check' ).each(
				function () {
					$( this ).prop( 'checked', $( this ).data( 'severity' ) === 'critical' );
				}
			);
			this.updateSelectionCount();
		},

		/**
		 * Update selection count badge.
		 */
		updateSelectionCount: function () {
			var count = $( '.turbo-guard-file-check:checked' ).length;
			$( '#turbo-guard-selection-count' ).text( count + ' selected' );

			// Enable/disable bulk action buttons.
			var disabled = count === 0;
			$( '#turbo-guard-delete-selected, #turbo-guard-quarantine-selected' ).prop( 'disabled', disabled );
		},

		/**
		 * Delete selected files.
		 */
		deleteSelected: function (e) {
			e.preventDefault();

			var ids = this.getSelectedIds();
			if (ids.length === 0) {
				alert( 'Please select at least one file.' );
				return;
			}

			if ( ! window.confirm( 'Delete ' + ids.length + ' file(s)? A backup ZIP will be created automatically before deletion.' )) {
				return;
			}

			this.performAction( 'delete', ids, 'turbo_guard_delete_files' );
		},

		/**
		 * Quarantine selected files.
		 */
		quarantineSelected: function (e) {
			e.preventDefault();

			var ids = this.getSelectedIds();
			if (ids.length === 0) {
				alert( 'Please select at least one file.' );
				return;
			}

			this.performAction( 'quarantine', ids, 'turbo_guard_quarantine_files' );
		},

		/**
		 * Delete single file (row action button).
		 */
		deleteSingle: function (e) {
			e.preventDefault();
			e.stopPropagation();

			var id = $( e.currentTarget ).data( 'id' );
			if ( ! id) {
				return;
			}

			if ( ! window.confirm( 'Delete this file? A backup will be created automatically.' )) {
				return;
			}

			this.performAction( 'delete', [id], 'turbo_guard_delete_files' );
		},

		/**
		 * Quarantine single file (row action button).
		 */
		quarantineSingle: function (e) {
			e.preventDefault();
			e.stopPropagation();

			var id = $( e.currentTarget ).data( 'id' );
			if ( ! id) {
				return;
			}

			this.performAction( 'quarantine', [id], 'turbo_guard_quarantine_files' );
		},

		/**
		 * Ignore a single file — marks it as safe and excludes it from future scans.
		 *
		 * This is the same pattern as Wordfence's "Ignore" button. The file is NOT
		 * deleted; it is just added to a permanent allowlist stored in wp_options.
		 * To undo, go to Settings → Ignored Files.
		 */
		ignoreSingle: function (e) {
			e.preventDefault();
			e.stopPropagation();

			var id  = $( e.currentTarget ).data( 'id' );
			if ( ! id) {
				return;
			}

			if ( ! window.confirm( 'Mark this file as safe?\n\nIt will be excluded from all future scans. Use this only if you are certain the file is NOT malicious.' )) {
				return;
			}

			var self    = this;
			var $row    = $( '.turbo-guard-result-row[data-id="' + id + '"]' );
			var $result = $( '#turbo-guard-action-result' );
			var $btn    = $( e.currentTarget );

			$btn.prop( 'disabled', true ).text( 'Ignoring...' );

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:    'turbo_guard_ignore_file',
						nonce:     turboGuardAdmin.nonce,
						result_id: id
					},
					success: function (response) {
						if (response.success) {
							$row.fadeOut(
								300,
								function () {
									$( this ).remove();

									// If no more rows, reload to show clean state.
									if ($( '.turbo-guard-result-row' ).length === 0) {
										location.reload();
									}
								}
							);

							$result
								.removeClass( 'notice-error' )
								.addClass( 'notice notice-success' )
								.html( '<p>&#128274; File marked as safe and excluded from future scans. <em>To undo, go to Settings &rarr; Ignored Files.</em></p>' )
								.show();

						} else {
							$result
								.removeClass( 'notice-success' )
								.addClass( 'notice notice-error' )
								.html( '<p>&#10007; ' + (response.data ? response.data.message : 'Could not ignore file.') + '</p>' )
								.show();
							$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-hidden" style="font-size:13px;width:13px;height:13px;vertical-align:middle;margin-right:3px;"></span> Ignore' );
						}
					},
					error: function (xhr) {
						$result
							.addClass( 'notice notice-error' )
							.html( '<p>&#10007; Server error: ' + xhr.status + '</p>' )
							.show();
						$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-hidden" style="font-size:13px;width:13px;height:13px;vertical-align:middle;margin-right:3px;"></span> Ignore' );
					}
				}
			);
		},

		/**
		 * Mark a finding as fixed — hides it from active results (Wordfence-style).
		 */
		markFixed: function (e) {
			e.preventDefault();
			e.stopPropagation();

			var id  = $( e.currentTarget ).data( 'id' );
			if ( ! id ) {
				return;
			}

			if ( ! window.confirm( 'Mark this finding as fixed?\n\nIt will be removed from the active results list. Use this only after you have resolved the issue.' ) ) {
				return;
			}

			var self    = this;
			var $row    = $( '.turbo-guard-result-row[data-id="' + id + '"]' );
			var $result = $( '#turbo-guard-action-result' );
			var $btn    = $( e.currentTarget );

			$btn.prop( 'disabled', true ).text( 'Marking...' );

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:    'turbo_guard_mark_fixed',
						nonce:     turboGuardAdmin.nonce,
						result_id: id
					},
					success: function (response) {
						if (response.success) {
							$row.fadeOut(
								300,
								function () {
									$( this ).remove();
									if ($( '.turbo-guard-result-row' ).length === 0) {
										location.reload();
									}
								}
							);
							$result
								.removeClass( 'notice-error' )
								.addClass( 'notice notice-success' )
								.html( '<p>&#10003; Finding marked as fixed.</p>' )
								.show();
						} else {
							$result
								.removeClass( 'notice-success' )
								.addClass( 'notice notice-error' )
								.html( '<p>&#10007; ' + (response.data ? response.data.message : 'Could not mark as fixed.') + '</p>' )
								.show();
							$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-yes" style="font-size:13px;width:13px;height:13px;vertical-align:middle;margin-right:3px;"></span> Mark as Fixed' );
						}
					},
					error: function (xhr) {
						$result
							.addClass( 'notice notice-error' )
							.html( '<p>&#10007; Server error: ' + xhr.status + '</p>' )
							.show();
						$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-yes" style="font-size:13px;width:13px;height:13px;vertical-align:middle;margin-right:3px;"></span> Mark as Fixed' );
					}
				}
			);
		},

		/**
		 * Delete a spam post from the database (DB scan result).
		 */
		deletePost: function (e) {
			e.preventDefault();
			e.stopPropagation();

			var postId   = $( e.currentTarget ).data( 'post-id' );
			var resultId = $( e.currentTarget ).data( 'result-id' );
			if ( ! postId ) { return; }

			if ( ! window.confirm( 'Permanently delete post #' + postId + ' from the database?\n\nThis cannot be undone.' ) ) {
				return;
			}

			var self    = this;
			var $row    = $( '.turbo-guard-result-row[data-id="' + resultId + '"]' );
			var $result = $( '#turbo-guard-action-result' );
			var $btn    = $( e.currentTarget );

			$btn.prop( 'disabled', true ).text( 'Deleting...' );

			$.ajax( {
				url:  turboGuardAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action:  'turbo_guard_delete_spam_post',
					nonce:   turboGuardAdmin.nonce,
					post_id: postId
				},
				success: function( response ) {
					if ( response.success ) {
						$row.fadeOut( 300, function() {
							$( this ).remove();
							if ( $( '.turbo-guard-result-row' ).length === 0 ) {
								location.reload();
							}
						} );
						$result
							.removeClass( 'notice-error' )
							.addClass( 'notice notice-success' )
							.html( '<p>&#10003; Post #' + postId + ' deleted from database.</p>' )
							.show();
					} else {
						$result
							.addClass( 'notice notice-error' )
							.html( '<p>&#10007; ' + ( response.data ? response.data.message : 'Could not delete post.' ) + '</p>' )
							.show();
						$btn.prop( 'disabled', false ).text( 'Delete Post' );
					}
				},
				error: function( xhr ) {
					$result
						.addClass( 'notice notice-error' )
						.html( '<p>&#10007; Server error: ' + xhr.status + '</p>' )
						.show();
					$btn.prop( 'disabled', false ).text( 'Delete Post' );
				}
			} );
		},

		/**
		 * Perform file delete or quarantine via AJAX.		 *
		 * Sends result_ids as result_ids[0], result_ids[1], ...
		 * so PHP receives a proper $_POST['result_ids'] array.
		 */
		performAction: function (type, ids, ajaxAction) {
			var self    = this;
			var $result = $( '#turbo-guard-action-result' );

			// Reset notice.
			$result.hide().removeClass( 'notice-success notice-error notice' ).html( '' );

			// Disable buttons during request.
			$( '#turbo-guard-delete-selected, #turbo-guard-quarantine-selected, .turbo-guard-delete-single, .turbo-guard-quarantine-single, .turbo-guard-ignore-single' ).prop( 'disabled', true );

			// Build POST data manually so arrays serialize correctly.
			var postData  = 'action=' + encodeURIComponent( ajaxAction ) + '&nonce=' + encodeURIComponent( turboGuardAdmin.nonce );
			var idsLength = ids.length;
			for (var i = 0; i < idsLength; i++) {
				postData += '&result_ids%5B%5D=' + encodeURIComponent( ids[i] );
			}

			$.ajax(
				{
					url:         turboGuardAdmin.ajaxUrl,
					type:        'POST',
					data:        postData,
					contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
					success: function (response) {
						if (response.success) {
							var data = response.data;

							// Fade out and remove each handled row.
							$.each(
								ids,
								function (i, id) {
									$( '.turbo-guard-result-row[data-id="' + id + '"]' ).fadeOut(
										300,
										function () {
											$( this ).remove();
										}
									);
								}
							);

							var msg = '';
							if (type === 'delete') {
								msg = '\u2713 Deleted <strong>' + (data.deleted || ids.length) + '</strong> file(s) successfully.';
								if (data.backup) {
									msg += ' Backup ZIP saved.';
								}
								if (data.failed && data.failed > 0) {
									msg += ' <span style="color:#d63638;">' + data.failed + ' file(s) could not be deleted (check file permissions).</span>';
								}
							} else {
								msg = '\u2713 Quarantined <strong>' + ids.length + '</strong> file(s) successfully.';
							}

							$result
							.addClass( 'notice notice-success' )
							.html( '<p>' + msg + '</p>' )
							.show();

							// Uncheck select-all.
							$( '#turbo-guard-select-all' ).prop( 'checked', false );

							// Reload page if no more rows.
							setTimeout(
								function () {
									if ($( '.turbo-guard-result-row' ).length === 0) {
										location.reload();
									}
								},
								800
							);

						} else {
							var errMsg = (response.data && response.data.message) ? response.data.message : 'Action failed. Check file permissions.';
							$result
							.addClass( 'notice notice-error' )
							.html( '<p>\u2717 ' + errMsg + '</p>' )
							.show();
						}
					},
					error: function (xhr, status, errorThrown) {
						$result
						.addClass( 'notice notice-error' )
						.html( '<p>\u2717 Server error: ' + status + ' ' + errorThrown + ' (Status ' + xhr.status + ')</p>' )
						.show();
					},
					complete: function () {
						// Re-enable all action buttons.
						$( '#turbo-guard-delete-selected, #turbo-guard-quarantine-selected, .turbo-guard-delete-single, .turbo-guard-quarantine-single, .turbo-guard-ignore-single' ).prop( 'disabled', false );
						self.updateSelectionCount();
					}
				}
			);
		},

		/**
		 * Get array of checked file IDs.
		 */
		getSelectedIds: function () {
			var ids = [];
			$( '.turbo-guard-file-check:checked' ).each(
				function () {
					ids.push( $( this ).val() );
				}
			);
			return ids;
		},

		// =========================================================
		// SETTINGS
		// =========================================================

		/**
		 * Save settings form via AJAX.
		 */
		saveSettings: function (e) {
			e.preventDefault();

			var self    = this;
			var $btn    = $( '#turbo-guard-save-settings' );
			var $result = $( '#turbo-guard-settings-result' );

			$btn.prop( 'disabled', true ).text( 'Saving...' );
			$result.hide().removeClass( 'notice-success notice-error notice' ).html( '' );

			// Collect all field values.
			var settings = {};

			$( '#turbo-guard-settings-form input[type="checkbox"]' ).each(
				function () {
					var name = $( this ).attr( 'name' );
					if ( ! name || name.slice( -2 ) === '[]' ) {
						return; // Grouped checkboxes are handled separately below.
					}
					settings[name] = $( this ).is( ':checked' ) ? 'yes' : 'no';
				}
			);

			// Grouped checkboxes (name ends with []) — e.g. required 2FA roles.
			var checkboxGroups = {};
			$( '#turbo-guard-settings-form input[type="checkbox"]' ).each(
				function () {
					var name = $( this ).attr( 'name' );
					if ( ! name || name.slice( -2 ) !== '[]' ) {
						return;
					}
					var base = name.slice( 0, -2 );
					if ( ! checkboxGroups[base] ) {
						checkboxGroups[base] = [];
					}
					if ( $( this ).is( ':checked' ) ) {
						checkboxGroups[base].push( $( this ).val() );
					}
				}
			);

			$( '#turbo-guard-settings-form input[type="text"], #turbo-guard-settings-form input[type="password"], #turbo-guard-settings-form input[type="number"], #turbo-guard-settings-form input[type="email"], #turbo-guard-settings-form select:not([multiple])' ).each(
				function () {
					var val  = $( this ).val();
					var name = $( this ).attr( 'name' );
					if ( ! name ) {
						return;
					}
					if (name === 'lockout_duration') {
						val = parseInt( val, 10 ) * 60; // convert minutes to seconds.
					}
					settings[name] = val;
				}
			);

			// Textarea fields (e.g. trusted_ips).
			$( '#turbo-guard-settings-form textarea' ).each( function () {
				var name = $( this ).attr( 'name' );
				if ( ! name ) {
					return;
				}
				settings[name] = $( this ).val();
			} );

			// Build POST string with settings as settings[key]=value.
			var postData = 'action=turbo_guard_save_settings&nonce=' + encodeURIComponent( turboGuardAdmin.nonce );
			$.each(
				settings,
				function (key, val) {
					postData += '&settings%5B' + encodeURIComponent( key ) + '%5D=' + encodeURIComponent( val );
				}
			);

			// Multi-select: allowed_countries[] — send as array.
			$( '#allowed_countries option:selected' ).each( function () {
				postData += '&settings%5Ballowed_countries%5D%5B%5D=' + encodeURIComponent( $( this ).val() );
			} );

			// Grouped checkboxes (e.g. required 2FA roles). Always send the key
			// so an emptied selection clears the stored value.
			$.each(
				checkboxGroups,
				function (base, vals) {
					if ( vals.length === 0 ) {
						postData += '&settings%5B' + encodeURIComponent( base ) + '%5D=';
					} else {
						$.each(
							vals,
							function (i, v) {
								postData += '&settings%5B' + encodeURIComponent( base ) + '%5D%5B%5D=' + encodeURIComponent( v );
							}
						);
					}
				}
			);

			$.ajax(
				{
					url:         turboGuardAdmin.ajaxUrl,
					type:        'POST',
					data:        postData,
					contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
					success: function (response) {
						if (response.success) {
							$result
							.addClass( 'notice notice-success' )
							.html( '<p>\u2713 Settings saved successfully!</p>' )
							.show();
						} else {
							$result
							.addClass( 'notice notice-error' )
							.html( '<p>\u2717 Failed to save settings.</p>' )
							.show();
						}
						setTimeout(
							function () {
								$result.fadeOut(); },
							3000
						);
					},
					complete: function () {
						$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-saved"></span> Save Settings' );
					}
				}
			);
		},

		// =========================================================
		// FIREWALL
		// =========================================================

		/**
		 * Block an IP address.
		 */
		blockIp: function (e) {
			e.preventDefault();

			var ip = $( '#turbo-guard-block-ip-input' ).val().trim();
			if ( ! ip) {
				alert( 'Please enter an IP address.' );
				return;
			}

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:     'turbo_guard_block_ip',
						nonce:      turboGuardAdmin.nonce,
						ip_address: ip
					},
					success: function (response) {
						if (response.success) {
							location.reload();
						} else {
							alert( 'Error: ' + (response.data ? response.data.message : 'Could not block IP') );
						}
					}
				}
			);
		},

		/**
		 * Unblock an IP address.
		 */
		unblockIp: function (e) {
			e.preventDefault();

			var ip = $( e.currentTarget ).data( 'ip' );
			if ( ! ip) {
				return;
			}

			if ( ! window.confirm( 'Unblock IP ' + ip + '?' )) {
				return;
			}

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:     'turbo_guard_unblock_ip',
						nonce:      turboGuardAdmin.nonce,
						ip_address: ip
					},
					success: function (response) {
						if (response.success) {
							location.reload();
						} else {
							alert( 'Error: ' + (response.data ? response.data.message : 'Could not unblock IP') );
						}
					}
				}
			);
		},

		/**
		 * Show/hide the rate-limit fields based on the master toggle.
		 */
		toggleRateLimitFields: function () {
			var enabled = $( '#turbo-guard-rate-limit-enabled' ).is( ':checked' );
			$( '.turbo-guard-rate-limit-field' ).toggle( enabled );
		},

		/**
		 * Handle the master toggle: update field visibility and persist the
		 * on/off state immediately (no Save click required).
		 */
		onRateLimitToggle: function () {
			var self    = this;
			var enabled = $( '#turbo-guard-rate-limit-enabled' ).is( ':checked' );
			var $status = $( '#turbo-guard-rate-limit-toggle-status' );

			this.toggleRateLimitFields();
			$status.text( 'Saving...' );

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:  'turbo_guard_toggle_rate_limiting',
						nonce:   turboGuardAdmin.nonce,
						enabled: enabled ? 'yes' : 'no'
					},
					success: function (response) {
						if (response.success) {
							$status.text( response.data.message );
							setTimeout( function () { $status.text( '' ); }, 2500 );
						} else {
							$status.text( (response.data ? response.data.message : 'Save failed.') );
							$( '#turbo-guard-rate-limit-enabled' ).prop( 'checked', ! enabled );
							self.toggleRateLimitFields();
						}
					},
					error: function () {
						$status.text( 'Save failed.' );
						$( '#turbo-guard-rate-limit-enabled' ).prop( 'checked', ! enabled );
						self.toggleRateLimitFields();
					}
				}
			);
		},

		/**
		 * Save firewall rate-limiting settings.
		 */
		saveRateLimits: function (e) {
			e.preventDefault();

			var $btn    = $( '#turbo-guard-rate-limit-form button[type="submit"]' );
			var $result = $( '#turbo-guard-rate-limit-result' );

			$btn.prop( 'disabled', true ).text( 'Saving...' );
			$result.removeClass( 'notice notice-success notice-error' ).text( '' );

			$.ajax(
				{
					url:  turboGuardAdmin.ajaxUrl,
					type: 'POST',
					data: {
						action:                    'turbo_guard_save_rate_limits',
						nonce:                     turboGuardAdmin.nonce,
						rate_limiting_enabled:     $( '#turbo-guard-rate-limit-form input[name="rate_limiting_enabled"]' ).is( ':checked' ) ? 'yes' : 'no',
						rate_limit:                $( '#turbo-guard-rate-limit' ).val(),
						rate_limit_404:            $( '#turbo-guard-rate-limit-404' ).val(),
						rate_limit_block_duration: $( '#turbo-guard-rate-limit-duration' ).val()
					},
					success: function (response) {
						$btn.prop( 'disabled', false ).text( 'Save Rate Limiting' );
						if (response.success) {
							$result.addClass( 'notice notice-success' ).text( response.data.message );
						} else {
							$result.addClass( 'notice notice-error' ).text( (response.data ? response.data.message : 'Could not save rate limiting settings.') );
						}
					},
					error: function () {
						$btn.prop( 'disabled', false ).text( 'Save Rate Limiting' );
						$result.addClass( 'notice notice-error' ).text( 'Request failed.' );
					}
				}
			);
		},

		// =========================================================
		// TWO-FACTOR AUTHENTICATION (settings page)
		// =========================================================

		/**
		 * Render the TOTP QR code for the pending 2FA setup, if present.
		 */
		init2fa: function () {
			var $toggle = $( '#2fa_enabled_global' );
			if ( $toggle.length ) {
				this.sync2faVisibility();
				$toggle.on( 'change', $.proxy( this.toggle2faGlobal, this ) );
			}

			var $setup = $( '.tg-2fa-setup' );
			if ( $setup.length && typeof qrcode === 'function' ) {
				this.render2faQr( $setup );
			}
		},

		/**
		 * Show/hide the 2FA options & setup depending on the enable toggle.
		 */
		sync2faVisibility: function () {
			var on = $( '#2fa_enabled_global' ).is( ':checked' );
			$( '#turbo-guard-2fa-options' ).toggle( on );
		},

		/**
		 * Persist the site-wide "Enable 2FA" toggle immediately.
		 */
		toggle2faGlobal: function (e) {
			var enabled = e.target.checked ? 'yes' : 'no';
			var $status = $( '#turbo-guard-2fa-toggle-status' );

			this.sync2faVisibility();
			$status.text( 'Saving…' );

			$.post(
				turboGuardAdmin.ajaxUrl,
				{
					action:  'turbo_guard_toggle_2fa',
					nonce:   turboGuardAdmin.nonce,
					enabled: enabled
				},
				function ( res ) {
					$status.text( res && res.success ? 'Saved' : 'Save failed' );
					window.setTimeout( function () { $status.text( '' ); }, 2000 );
				}
			).fail(
				function () {
					$status.text( 'Save failed' );
					window.setTimeout( function () { $status.text( '' ); }, 2000 );
				}
			);
		},

		render2faQr: function ( $setup ) {
			var $wrap = $( '#turbo-guard-2fa-qr' );
			if ( ! $wrap.length ) {
				return;
			}

			var secret  = $setup.data( 'secret' );
			var account = $setup.data( 'account' );
			var issuer  = $setup.data( 'issuer' );
			if ( ! secret ) {
				return;
			}

			var label = ( issuer ? issuer + ':' : '' ) + account;
			var uri   = 'otpauth://totp/' + encodeURIComponent( label ) +
				'?secret=' + encodeURIComponent( secret ) +
				'&issuer=' + encodeURIComponent( issuer ) +
				'&algorithm=SHA1&digits=6&period=30';

			try {
				var qr = qrcode( 0, 'M' );
				qr.addData( uri );
				qr.make();
				$wrap.html( qr.createSvgTag( 4, 0 ) );
				$wrap.find( 'svg' ).css( { width: '180px', height: '180px' } );
			} catch ( e ) {
				$wrap.text( 'QR unavailable — use the manual key below.' );
			}
		},

		enable2fa: function () {
			var $setup = $( '.tg-2fa-setup' );
			var $btn   = $( '#turbo-guard-2fa-enable' );
			var code   = $.trim( $( '#turbo-guard-2fa-code' ).val() );
			var secret = $setup.data( 'secret' );

			if ( ! code ) {
				this.show2faResult( turboGuardAdmin.strings.tg2faEnterCode, 'error' );
				return;
			}

			$btn.prop( 'disabled', true );

			$.post(
				turboGuardAdmin.ajaxUrl,
				{
					action: 'turbo_guard_2fa_enable',
					nonce:  turboGuardAdmin.nonce,
					secret: secret,
					code:   code
				},
				$.proxy(
					function ( res ) {
						$btn.prop( 'disabled', false );
						if ( res && res.success ) {
							this.show2faResult( res.data.message, 'success', res.data.recovery );
						} else {
							this.show2faResult( ( res && res.data && res.data.message ) || turboGuardAdmin.strings.tg2faInvalid, 'error' );
						}
					},
					this
				)
			).fail(
				$.proxy(
					function () {
						$btn.prop( 'disabled', false );
						this.show2faResult( turboGuardAdmin.strings.tg2faError, 'error' );
					},
					this
				)
			);
		},

		disable2fa: function () {
			// eslint-disable-next-line no-alert
			if ( ! window.confirm( 'Disable two-factor authentication for your account?' ) ) {
				return;
			}

			var $btn = $( '#turbo-guard-2fa-disable' );
			$btn.prop( 'disabled', true );

			$.post(
				turboGuardAdmin.ajaxUrl,
				{
					action: 'turbo_guard_2fa_disable',
					nonce:  turboGuardAdmin.nonce
				},
				$.proxy(
					function ( res ) {
						if ( res && res.success ) {
							window.location.reload();
						} else {
							$btn.prop( 'disabled', false );
							this.show2faResult( ( res && res.data && res.data.message ) || turboGuardAdmin.strings.tg2faError, 'error' );
						}
					},
					this
				)
			);
		},

		regenerate2fa: function () {
			var $btn = $( '#turbo-guard-2fa-regen' );
			$btn.prop( 'disabled', true );

			$.post(
				turboGuardAdmin.ajaxUrl,
				{
					action: 'turbo_guard_2fa_regenerate',
					nonce:  turboGuardAdmin.nonce
				},
				$.proxy(
					function ( res ) {
						$btn.prop( 'disabled', false );
						if ( res && res.success ) {
							this.show2faResult( res.data.message, 'success', res.data.recovery );
						} else {
							this.show2faResult( ( res && res.data && res.data.message ) || turboGuardAdmin.strings.tg2faError, 'error' );
						}
					},
					this
				)
			);
		},

		show2faResult: function ( message, type, codes ) {
			var $result = $( '#turbo-guard-2fa-result' );
			var html    = '<p>' + $( '<div/>' ).text( message ).html() + '</p>';

			if ( codes && codes.length ) {
				html += '<ul style="margin:8px 0 0;padding-left:22px;font-family:monospace;">';
				$.each(
					codes,
					function ( i, c ) {
						html += '<li>' + $( '<div/>' ).text( c ).html() + '</li>';
					}
				);
				html += '</ul>';
			}

			$result
				.removeClass( 'notice-success notice-error notice-warning' )
				.addClass( 'notice ' + ( type === 'success' ? 'notice-success' : 'notice-error' ) )
				.html( html )
				.show();
		}
	};

	// Boot on DOM ready.
	$( document ).ready(
		function () {
			TurboGuard.init();
		}
	);

})( jQuery );


/**
 * =========================================================
 * Google Search Console (GSC) Module
 * =========================================================
 */
jQuery( function( $ ) {

var TurboGuardGSC = {

	// All URLs (structured: { url, spam, label } — spam detected server-side).
	allUrls: [],

	init: function () {
		if ( $( '#turbo-guard-scan-site' ).length === 0 ) {
			return; // Not on GSC page.
		}
		this.bindEvents();
	},

	bindEvents: function () {
		$( '#turbo-guard-scan-site' ).on( 'click', $.proxy( this.scanSitemap, this ) );
		$( '#turbo-guard-fetch-urls' ).on( 'click', $.proxy( this.fetchUrls, this ) );
		$( '#turbo-guard-gsc-select-all' ).on( 'change', $.proxy( this.toggleSelectAll, this ) );
		$( '#turbo-guard-select-spam-only' ).on( 'click', $.proxy( this.selectSpamOnly, this ) );
		$( '#turbo-guard-generate-htaccess' ).on( 'click', $.proxy( this.generateHtaccess, this ) );
		$( '#turbo-guard-apply-htaccess' ).on( 'click', $.proxy( this.applyHtaccess, this ) );
		$( '#turbo-guard-copy-htaccess' ).on( 'click', this.copyHtaccess );
		$( '#turbo-guard-filter-spam' ).on( 'change', $.proxy( this.renderTable, this ) );
		$( '#turbo-guard-gsc-disconnect' ).on( 'click', $.proxy( this.disconnect, this ) );
		$( document ).on( 'change', '.turbo-guard-gsc-check', $.proxy( this.updateSelectionCount, this ) );
	},

	/**
	 * Scan the site's own sitemap for spam URLs (no Google OAuth needed).
	 */
	scanSitemap: function (e) {
		e.preventDefault();

		var self  = this;
		var $btn  = $( '#turbo-guard-scan-site' );
		$btn.prop( 'disabled', true ).text( 'Scanning...' );
		$( '#turbo-guard-gsc-loading' ).show();
		$( '#turbo-guard-gsc-notice' ).hide().removeClass( 'notice notice-success notice-error' );

		$.ajax(
			{
				url:  turboGuardAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'turbo_guard_gsc_scan_sitemap',
					nonce:  turboGuardAdmin.nonce
				},
				success: function (response) {
					if (response.success) {
						self.allUrls = response.data.urls || [];
						self.renderTable();
						$( '#turbo-guard-gsc-results' ).show();
						if (self.allUrls.length === 0) {
							$( '#turbo-guard-gsc-notice' )
								.addClass( 'notice notice-success' )
								.html( '<p>&#10003; No spam URLs found in your sitemap — your site looks clean.</p>' )
								.show();
						}
					} else {
						$( '#turbo-guard-gsc-notice' )
							.addClass( 'notice notice-error' )
							.html( '<p>&#10007; ' + (response.data ? response.data.message : 'Scan failed.') + '</p>' )
							.show();
					}
				},
				error: function (xhr) {
					$( '#turbo-guard-gsc-notice' )
						.addClass( 'notice notice-error' )
						.html( '<p>Server error: ' + xhr.status + '</p>' )
						.show();
				},
				complete: function () {
					$( '#turbo-guard-gsc-loading' ).hide();
					$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-search"></span> Scan Site for Spam' );
				}
			}
		);
	},

	/**
	 * Fetch indexed URLs from Google via AJAX.
	 */
	fetchUrls: function (e) {
		e.preventDefault();

		var self = this;
		var $btn = $( '#turbo-guard-fetch-urls' );

		$btn.prop( 'disabled', true ).text( 'Fetching...' );
		$( '#turbo-guard-gsc-loading' ).show();
		$( '#turbo-guard-gsc-results' ).hide();

		$.ajax(
			{
				url:  turboGuardAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'turbo_guard_gsc_get_urls',
					nonce:  turboGuardAdmin.nonce
				},
				success: function (response) {
					if (response.success) {
						self.allUrls = response.data.urls || [];
						self.renderTable();
						$( '#turbo-guard-gsc-results' ).show();
					} else {
						$( '#turbo-guard-gsc-notice' )
						.addClass( 'notice notice-error' )
						.html( '<p>Error: ' + (response.data ? response.data.message : 'Failed to fetch URLs') + '</p>' )
						.show();
					}
				},
				error: function (xhr) {
					$( '#turbo-guard-gsc-notice' )
					.addClass( 'notice notice-error' )
					.html( '<p>Server error: ' + xhr.status + '</p>' )
					.show();
				},
				complete: function () {
					$( '#turbo-guard-gsc-loading' ).hide();
					$btn.prop( 'disabled', false ).html( '<span class="dashicons dashicons-download"></span> Fetch Indexed URLs from Google' );
				}
			}
		);
	},

	/**
	 * Render URL table (spam type + label come from the server).
	 */
	renderTable: function () {
		var filterSpam = $( '#turbo-guard-filter-spam' ).is( ':checked' );
		var $tbody     = $( '#turbo-guard-url-tbody' );
		var spamCount  = 0;
		var rows       = '';

		this.allUrls.forEach(
			function (item) {
				var url  = item.url;
				var spam = item.spam;

				if (spam) {
					spamCount++;
				}
				if (filterSpam && ! spam) {
					return;
				}

				var badgeHtml = spam
					? '<span class="turbo-guard-badge turbo-guard-badge-critical">' + (item.label || 'Spam') + '</span>'
					: '<span class="turbo-guard-badge turbo-guard-badge-info">Normal</span>';

				rows += '<tr class="' + (spam ? 'turbo-guard-spam-row' : '') + '">' +
					'<td><input type="checkbox" class="turbo-guard-gsc-check" value="' + url + '" data-spam="' + (spam || '') + '" /></td>' +
					'<td class="turbo-guard-url-cell"><a href="' + url + '" target="_blank" rel="noopener">' + url + '</a></td>' +
					'<td>' + badgeHtml + '</td>' +
					'</tr>';
			}
		);

		$tbody.html( rows || '<tr><td colspan="3" style="text-align:center;padding:20px;">No URLs found matching filter.</td></tr>' );

		$( '#turbo-guard-url-count' ).text( this.allUrls.length );
		$( '#turbo-guard-spam-count' ).html(
			'<span style="color:#d63638;font-weight:600;">' + spamCount + ' suspected spam</span>'
		);

		this.updateSelectionCount();
	},

	/**
	 * Toggle select all.
	 */
	toggleSelectAll: function () {
		var checked = $( '#turbo-guard-gsc-select-all' ).is( ':checked' );
		$( '.turbo-guard-gsc-check:visible' ).prop( 'checked', checked );
		this.updateSelectionCount();
	},

	/**
	 * Select only spam URLs.
	 */
	selectSpamOnly: function () {
		$( '.turbo-guard-gsc-check' ).each(
			function () {
				$( this ).prop( 'checked', ! ! $( this ).data( 'spam' ) );
			}
		);
		this.updateSelectionCount();
	},

	/**
	 * Update selection count badge.
	 */
	updateSelectionCount: function () {
		var count = $( '.turbo-guard-gsc-check:checked' ).length;
		$( '#turbo-guard-gsc-selection-count' ).text( count + ' selected' );
		$( '#turbo-guard-generate-htaccess, #turbo-guard-apply-htaccess' ).prop( 'disabled', count === 0 );
	},

	/**
	 * Get selected URLs.
	 */
	getSelectedUrls: function () {
		var urls = [];
		$( '.turbo-guard-gsc-check:checked' ).each(
			function () {
				urls.push( $( this ).val() );
			}
		);
		return urls;
	},

	/**
	 * Generate .htaccess 410-Gone blocking rules (server-side).
	 */
	generateHtaccess: function (e) {
		e.preventDefault();

		var urls = this.getSelectedUrls();
		if (urls.length === 0) {
			alert( 'Select at least one URL.' ); return; }

		var $btn = $( '#turbo-guard-generate-htaccess' );
		$btn.prop( 'disabled', true ).text( 'Generating...' );

		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_gsc_generate_htaccess', nonce: turboGuardAdmin.nonce, urls: urls },
			function (r) {
				$btn.prop( 'disabled', false ).text( 'Generate .htaccess 410 Blocks' );
				if (r.success) {
					$( '#turbo-guard-htaccess-code' ).val( r.data.rules );
					$( '#turbo-guard-htaccess-preview' ).show();
					$( 'html,body' ).animate( { scrollTop: $( '#turbo-guard-htaccess-preview' ).offset().top - 50 }, 400 );
				} else {
					$( '#turbo-guard-gsc-notice' )
						.removeClass( 'notice-success' )
						.addClass( 'notice notice-error' )
						.html( '<p>' + (r.data ? r.data.message : 'Failed to generate rules.') + '</p>' )
						.show();
				}
			}
		);
	},

	/**
	 * Apply 410-Gone rules to .htaccess directly (Pro).
	 */
	applyHtaccess: function (e) {
		e.preventDefault();

		var urls = this.getSelectedUrls();
		if (urls.length === 0) {
			alert( 'Select at least one URL.' ); return; }

		if ( ! window.confirm( 'Write these 410-Gone rules to your .htaccess file? A timestamped backup is saved automatically before writing.' ) ) {
			return;
		}

		var $btn = $( '#turbo-guard-apply-htaccess' );
		$btn.prop( 'disabled', true ).text( 'Applying...' );

		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_gsc_apply_htaccess', nonce: turboGuardAdmin.nonce, urls: urls },
			function (r) {
				$btn.prop( 'disabled', false ).text( 'Apply to .htaccess' );
				if (r.success) {
					$( '#turbo-guard-gsc-notice' )
						.removeClass( 'notice-error' )
						.addClass( 'notice notice-success' )
						.html( '<p>&#10003; ' + (r.data ? r.data.message : '.htaccess updated.') + '</p>' )
						.show();
				} else {
					$( '#turbo-guard-gsc-notice' )
						.removeClass( 'notice-success' )
						.addClass( 'notice notice-error' )
						.html( '<p>&#10007; ' + (r.data ? r.data.message : 'Failed to update .htaccess.') + '</p>' )
						.show();
				}
			}
		);
	},

	/**
	 * Copy htaccess code to clipboard.
	 */
	copyHtaccess: function () {
		var $textarea = $( '#turbo-guard-htaccess-code' );
		$textarea[0].select();
		document.execCommand( 'copy' );
		$( '#turbo-guard-copy-htaccess' ).text( 'Copied!' );
		setTimeout(
			function () {
				$( '#turbo-guard-copy-htaccess' ).html( '<span class="dashicons dashicons-clipboard"></span> Copy to Clipboard' );
			},
			2000
		);
	},

	/**
	 * Resubmit sitemap after cleanup.
	 */
	resubmitSitemap: function () {
		$.post(
			turboGuardAdmin.ajaxUrl,
			{
				action: 'turbo_guard_gsc_submit_sitemap',
				nonce:  turboGuardAdmin.nonce
			},
			function (response) {
				if (response.success) {
					$( '#turbo-guard-gsc-notice' ).append( ' Sitemap resubmitted to Google. &#10003;' );
				}
			}
		);
	},

	/**
	 * Disconnect GSC.
	 */
	disconnect: function (e) {
		e.preventDefault();
		if ( ! window.confirm( 'Disconnect Google Search Console? You will need to reconnect to use this feature.' )) {
			return;
		}
		$.post(
			turboGuardAdmin.ajaxUrl,
			{
				action: 'turbo_guard_gsc_disconnect',
				nonce:  turboGuardAdmin.nonce
			},
			function () {
				location.reload();
			}
		);
	}
};

// Initialize GSC module — wrapped inside jQuery IIFE above.
TurboGuardGSC.init();

} ); // end jQuery GSC wrapper


/**
 * GSC Setup: Copy redirect URI button.
 */
jQuery( document ).ready( function( $ ) {
	$( document ).on( 'click', '.turbo-guard-copy-redirect-uri', function() {
		var uri = $( this ).data( 'uri' );
		if ( navigator.clipboard ) {
			navigator.clipboard.writeText( uri );
		} else {
			// Fallback.
			var $tmp = $( '<input>' );
			$( 'body' ).append( $tmp );
			$tmp.val( uri ).select();
			document.execCommand( 'copy' );
			$tmp.remove();
		}
		var $btn = $( this );
		$btn.text( 'Copied!' );
		setTimeout( function() { $btn.text( 'Copy' ); }, 2000 );
	} );
} );


/**
 * =========================================================
 * Vulnerability Scanner Page
 * =========================================================
 */

jQuery( document ).ready( function( $ ) {
	$( '#turbo-guard-run-vuln-scan' ).on( 'click', function(e) {
		e.preventDefault();

		var $btn     = $( this );
		var $loading = $( '#turbo-guard-vuln-scanning' );
		var $notice  = $( '#turbo-guard-vuln-notice' );

		$btn.prop( 'disabled', true );
		$loading.show();
		$notice.hide().removeClass( 'notice-success notice-error notice-warning notice' );

		$.ajax( {
			url:     turboGuardAdmin.ajaxUrl,
			type:    'POST',
			timeout: 120000, // 2 minutes for large sites.
			data: {
				action: 'turbo_guard_run_vuln_scan',
				nonce:  turboGuardAdmin.nonce
			},
			success: function( response ) {
				if ( response.success ) {
					var isLimited = ( response.data.status && 'success' !== response.data.status );
					$notice
						.addClass( isLimited ? 'notice notice-warning' : 'notice notice-success' )
						.html( '<p>' + ( isLimited ? '\u26a0 ' : '\u2713 ' ) + response.data.message + ' <a href="' + window.location.href + '">Refresh to see results</a></p>' )
						.show();

					// Auto-reload after 2 seconds to show updated results.
					setTimeout( function() { location.reload(); }, 2000 );
				} else {
					$notice
						.addClass( 'notice notice-error' )
						.html( '<p>\u2717 ' + ( response.data ? response.data.message : 'Scan failed.' ) + '</p>' )
						.show();
				}
			},
			error: function( xhr ) {
				$notice
					.addClass( 'notice notice-error' )
					.html( '<p>\u2717 Request error: ' + xhr.status + '. The scan may still be running — refresh the page in a moment.</p>' )
					.show();
			},
			complete: function() {
				$btn.prop( 'disabled', false );
				$loading.hide();
			}
		} );
	} );
} );


/**
 * =========================================================
 * Remote Notices Module — v1.3.0
 * Handles dismissal of remote notification banners fetched
 * from the Turbo Addons notification server.
 * =========================================================
 */
( function ( $ ) {
	'use strict';

	var TurboGuardNotices = {

		init: function () {
			this.bindEvents();
		},

		bindEvents: function () {
			// Dismiss button click — works for any notice rendered now or later.
			$( document ).on( 'click', '.tg-notice-dismiss', $.proxy( this.dismiss, this ) );
		},

		/**
		 * Send dismiss AJAX request, then slide-remove the banner.
		 */
		dismiss: function ( e ) {
			e.preventDefault();

			var $btn      = $( e.currentTarget );
			var noticeId  = $btn.data( 'notice-id' );
			var nonce     = $btn.data( 'nonce' );
			var $notice   = $( '#tg-notice-' + noticeId );

			if ( ! noticeId || ! nonce ) {
				// No ID or nonce — just hide visually.
				$notice.slideUp( 200 );
				return;
			}

			// Optimistic UI: hide immediately so it feels instant.
			$notice.slideUp( 180 );

			$.ajax( {
				url:  turboGuardAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action:    'turbo_guard_dismiss_notice',
					notice_id: noticeId,
					nonce:     nonce
				},
				error: function () {
					// Silent failure — notice is already hidden visually.
				}
			} );
		}
	};

	$( document ).ready( function () {
		TurboGuardNotices.init();
	} );

} )( jQuery );


/**
 * =========================================================
 * SEO Spam Detector — Scan + Delete
 * =========================================================
 */

jQuery( document ).ready( function( $ ) {
	var strings = turboGuardAdmin.strings || {};

	$( '#turbo-guard-run-seo-scan' ).on( 'click', function() {
		var $btn     = $( this ).prop( 'disabled', true );
		var $loading = $( '#turbo-guard-seo-scanning' );
		var $notice  = $( '#turbo-guard-seo-notice' );
		$loading.show();
		$notice.hide().removeClass( 'notice-success notice-error notice' );
		$.ajax( {
			url: turboGuardAdmin.ajaxUrl, type: 'POST', timeout: 60000,
			data: { action: 'turbo_guard_run_seo_spam_scan', nonce: turboGuardAdmin.nonce },
			success: function( r ) {
				if ( r.success ) {
					var msg = r.data.total > 0
						? '&#9888; ' + r.data.total + ' ' + ( strings.seoSpamFound || 'spam indicator(s) found.' )
						: '&#10003; ' + ( strings.noSeoSpamFound || 'No SEO spam found.' );
					$notice
						.addClass( 'notice notice-' + ( r.data.total > 0 ? 'error' : 'success' ) )
						.html( '<p>' + msg + '</p>' )
						.show();
					setTimeout( function() { location.reload(); }, 1500 );
				} else {
					$notice
						.addClass( 'notice notice-error' )
						.html( '<p>&#10007; ' + ( r.data ? r.data.message : ( strings.seoScanFailed || 'Scan failed.' ) ) + '</p>' )
						.show();
				}
			},
			error: function( xhr ) {
				$notice
					.addClass( 'notice notice-error' )
					.html( '<p>&#10007; Server error: ' + xhr.status + '</p>' )
					.show();
			},
			complete: function() { $btn.prop( 'disabled', false ); $loading.hide(); }
		} );
	} );

	var doDeleteSpamPost = function( id, mode, nonce, $btn ) {
		$btn.prop( 'disabled', true ).text( strings.deleting || 'Deleting...' );
		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_delete_spam_post', nonce: nonce, post_id: id, mode: mode },
			function( r ) {
				if ( r.success ) {
					$btn.closest( 'tr' ).fadeOut( 300, function() { $( this ).remove(); } );
				} else {
					$btn.prop( 'disabled', false ).text( strings.deleteFree || 'Delete' );
					if ( r.data && r.data.message ) {
						alert( String( r.data.message ).replace( /<[^>]*>/g, '' ) );
					}
				}
			}
		);
	};

	$( document ).on( 'click', '.turbo-guard-delete-spam-post', function() {
		var $btn  = $( this );
		var id    = $btn.data( 'id' );
		var nonce = $btn.data( 'nonce' ) || turboGuardAdmin.nonce;
		var isPro = !!turboGuardAdmin.isPro;

		var overlay = $( '<div class="tg-modal-overlay"></div>' );
		var dialog  = $( '<div class="tg-modal"></div>' ).append(
			$( '<h3></h3>' ).text( strings.seoDeleteTitle || 'Remove this spam post?' ),
			$( '<p></p>' ).text( strings.seoDeleteBody || 'Choose how you want to remove this spam post.' ),
			$( '<div class="tg-modal-actions"></div>' ).append(
				$( '<button type="button" class="button button-primary tg-seo-trash"></button>' ).text( strings.seoTrashOption || 'Move to Trash (recoverable)' ),
				$( '<button type="button" class="button tg-seo-permanent" style="color:#b91c1c;border-color:#fca5a5;"></button>' ).text( strings.seoPermanentOption || 'Delete Permanently' ),
				$( '<button type="button" class="button tg-seo-cancel"></button>' ).text( strings.cancel || 'Cancel' )
			)
		);
		overlay.append( dialog );
		$( 'body' ).append( overlay );

		var close = function() { overlay.remove(); };
		dialog.find( '.tg-seo-cancel' ).on( 'click', close );
		overlay.on( 'click', function( e ) { if ( e.target === overlay[0] ) { close(); } } );

		dialog.find( '.tg-seo-trash' ).on( 'click', function() { close(); doDeleteSpamPost( id, 'trash', nonce, $btn ); } );
		dialog.find( '.tg-seo-permanent' ).on( 'click', function() {
			close();
			if ( ! isPro ) {
				alert( strings.seoPermanentUpgrade || 'Permanent delete is a Pro feature. Upgrade to Turbo Guard Pro, or move the post to Trash instead.' );
				return;
			}
			doDeleteSpamPost( id, 'delete', nonce, $btn );
		} );
	} );

	$( '#turbo-guard-delete-all-spam-posts' ).on( 'click', function() {
		var ids = $( this ).data( 'ids' ).toString().split( ',' ).filter( Boolean );
		if ( ! ids.length ) {
			return;
		}
		if ( ! window.confirm( strings.confirmDeleteAllSpamPosts || 'Move all selected spam posts to Trash? This can be undone from the Trash.' ) ) {
			return;
		}
		var $btn = $( this ).prop( 'disabled', true ).text( strings.deleting || 'Deleting...' );

		var next = function( idx ) {
			if ( idx >= ids.length ) {
				location.reload();
				return;
			}
			$.post(
				turboGuardAdmin.ajaxUrl,
				{ action: 'turbo_guard_delete_spam_post', nonce: turboGuardAdmin.nonce, post_id: parseInt( ids[idx], 10 ), mode: 'trash' },
				function() { next( idx + 1 ); }
			);
		};
		next( 0 );
	} );

	$( document ).on( 'click', '.turbo-guard-ignore-seo-spam', function() {
		var $btn = $( this );
		if ( ! window.confirm( strings.confirmIgnoreSeoSpam || 'Mark this item as safe and exclude it from future scans?' ) ) {
			return;
		}
		var bucket = $btn.data( 'bucket' );
		var key    = $btn.data( 'key' );
		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_ignore_seo_spam', nonce: turboGuardAdmin.nonce, bucket: bucket, key: key },
			function( r ) {
				if ( r.success ) {
					$btn.closest( 'tr' ).fadeOut( 300, function() { $( this ).remove(); } );
				} else {
					alert( ( r.data && r.data.message ? String( r.data.message ) : 'Failed to ignore item.' ).replace( /<[^>]*>/g, '' ) );
				}
			}
		);
	} );

	$( document ).on( 'click', '.turbo-guard-delete-spam-file', function() {
		var $btn = $( this );
		var path = $btn.data( 'path' );
		if ( ! path ) {
			return;
		}
		if ( ! window.confirm( strings.confirmDeleteSpamFile || 'Delete this spam file? A backup ZIP is created automatically.' ) ) {
			return;
		}
		$btn.prop( 'disabled', true ).text( strings.deleting || 'Deleting...' );
		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_delete_spam_file', nonce: turboGuardAdmin.nonce, path: path },
			function( r ) {
				if ( r.success ) {
					$btn.closest( 'tr' ).fadeOut( 300, function() { $( this ).remove(); } );
				} else {
					$btn.prop( 'disabled', false ).text( strings.deleteFree || 'Delete' );
					if ( r.data && r.data.message ) {
						alert( String( r.data.message ).replace( /<[^>]*>/g, '' ) );
					}
				}
			}
		);
	} );

	$( '#turbo-guard-delete-all-spam-files' ).on( 'click', function() {
		var $btn = $( this );
		var paths;
		try {
			paths = JSON.parse( $btn.attr( 'data-paths' ) || '[]' );
		} catch ( e ) {
			paths = [];
		}
		if ( ! paths.length ) {
			return;
		}
		if ( ! window.confirm( strings.confirmDeleteAllSpamFiles || 'Delete all selected spam files? A backup ZIP is created automatically.' ) ) {
			return;
		}
		$btn.prop( 'disabled', true ).text( strings.deleting || 'Deleting...' );

		var next = function( idx ) {
			if ( idx >= paths.length ) {
				location.reload();
				return;
			}
			$.post(
				turboGuardAdmin.ajaxUrl,
				{ action: 'turbo_guard_delete_spam_file', nonce: turboGuardAdmin.nonce, path: paths[idx] },
				function() { next( idx + 1 ); }
			);
		};
		next( 0 );
	} );
} );


/**
 * =========================================================
 * Malware Scanner — Quick Delete Critical Files
 * =========================================================
 */

jQuery( document ).ready( function( $ ) {
	$( '#turbo-guard-quick-delete-critical' ).on( 'click', function() {
		var $btn  = $( this );
		var limit = parseInt( $btn.attr( 'data-limit' ), 10 );

		// Uncheck all, then check critical files up to the allowed limit.
		$( '.turbo-guard-file-check' ).prop( 'checked', false );

		if ( turboGuardAdmin.isPro ) {
			$( '.turbo-guard-file-check[data-severity="critical"]' ).prop( 'checked', true );
		} else {
			$( '.turbo-guard-file-check[data-severity="critical"]' ).slice( 0, limit ).prop( 'checked', true );
		}

		// Refresh selection count + button state.
		var count = $( '.turbo-guard-file-check:checked' ).length;
		$( '#turbo-guard-selection-count' ).text( count + ' selected' );
		$( '#turbo-guard-delete-selected, #turbo-guard-quarantine-selected' ).prop( 'disabled', count === 0 );

		$( 'html,body' ).animate( { scrollTop: $( '#turbo-guard-delete-selected' ).offset().top - 100 }, 400 );
		$( '#turbo-guard-delete-selected' ).trigger( 'click' );
	} );
} );


/**
 * =========================================================
 * File Integrity — Checks, Watcher, Baseline
 * =========================================================
 */

jQuery( function( $ ) {
	var strings = turboGuardAdmin.strings || {};

	function showNotice( msg, type ) {
		$( '#turbo-guard-integrity-notice' )
			.removeClass( 'notice-success notice-error notice-warning notice' )
			.addClass( 'notice notice-' + type )
			.html( '<p>' + msg + '</p>' )
			.show();
	}

	$( '#tg-run-integrity' ).on( 'click', function() {
		var $btn = $( this ).prop( 'disabled', true ).text( strings.checking || 'Checking...' );
		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_run_integrity_check', nonce: turboGuardAdmin.nonce },
			function( r ) {
				if ( r.success ) {
					showNotice( '\u2713 ' + r.data.message, r.data.modified + r.data.missing > 0 ? 'error' : 'success' );
					setTimeout( function() { location.reload(); }, 1500 );
				} else {
					showNotice( '\u2717 ' + ( r.data ? r.data.message : 'Failed.' ), 'error' );
				}
			}
		).always( function() { $btn.prop( 'disabled', false ).text( strings.runCheckNow || 'Run Check Now' ); } );
	} );

	$( '#tg-run-watcher' ).on( 'click', function() {
		var $btn = $( this ).prop( 'disabled', true ).text( strings.scanning || 'Scanning...' );
		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_run_file_watcher', nonce: turboGuardAdmin.nonce },
			function( r ) {
				if ( r.success ) {
					showNotice( '\u2713 ' + r.data.message, r.data.new > 0 ? 'error' : 'success' );
					setTimeout( function() { location.reload(); }, 1500 );
				} else {
					showNotice( '\u2717 ' + ( r.data ? r.data.message : 'Failed.' ), 'error' );
				}
			}
		).always( function() { $btn.prop( 'disabled', false ).text( strings.runNow || 'Run Now' ); } );
	} );

	$( '#tg-rebuild-baseline' ).on( 'click', function() {
		if ( ! window.confirm( strings.confirmRebuildBaseline || 'Rebuild baseline? This marks all current files as trusted. Only do this on a clean site.' ) ) {
			return;
		}
		var $btn = $( this ).prop( 'disabled', true ).text( strings.building || 'Building...' );
		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_rebuild_baseline', nonce: turboGuardAdmin.nonce },
			function( r ) {
				if ( r.success ) {
					showNotice( '\u2713 ' + r.data.message, 'success' );
					setTimeout( function() { location.reload(); }, 1500 );
				} else {
					showNotice( '\u2717 ' + ( r.data ? r.data.message : 'Failed.' ), 'error' );
				}
			}
		).always( function() { $btn.prop( 'disabled', false ).text( strings.rebuildBaseline || 'Rebuild Baseline' ); } );
	} );

	// Toggle automatic integrity features (file watcher / daily core check).
	$( document ).on( 'change', '.tg-integrity-auto-toggle', function() {
		var $toggle = $( this );
		var key     = $toggle.data( 'key' );
		var enabled = $toggle.is( ':checked' ) ? 'yes' : 'no';

		$toggle.prop( 'disabled', true );

		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_toggle_integrity_setting', nonce: turboGuardAdmin.nonce, key: key, enabled: enabled },
			function( r ) {
				$toggle.prop( 'disabled', false );
				if ( r.success ) {
					showNotice( '\u2713 ' + ( r.data.message || 'Updated.' ), 'success' );
					// Reload so the card's schedule label reflects the new state.
					setTimeout( function() { location.reload(); }, 800 );
				} else {
					showNotice( '\u2717 ' + ( r.data && r.data.message ? r.data.message : 'Update failed.' ), 'error' );
					$toggle.prop( 'checked', ! $toggle.is( ':checked' ) );
				}
			}
		).fail( function() {
			$toggle.prop( 'disabled', false );
			$toggle.prop( 'checked', ! $toggle.is( ':checked' ) );
			showNotice( '\u2717 Server error while updating.', 'error' );
		} );
	} );
} );


/**
 * =========================================================
 * Malware Scanner — View File (Pro) + Free Upsell Tooltip
 * =========================================================
 */

jQuery( function( $ ) {
	var strings = turboGuardAdmin.strings || {};
	var isPro   = !! turboGuardAdmin.isPro;
	var proUrl  = turboGuardAdmin.proUrl || '#';

	var $modal = $( '#turbo-guard-view-modal' );

	// Close the modal (overlay, close button, or Esc).
	function closeModal() {
		$modal.hide();
	}

	$( document ).on( 'click', '.turbo-guard-view-modal-close, .turbo-guard-view-modal-overlay', closeModal );
	$( document ).on( 'keyup', function( e ) {
		if ( e.key === 'Escape' || e.keyCode === 27 ) {
			closeModal();
		}
	} );

	// Handle "View" button click on each result row.
	$( document ).on( 'click', '.turbo-guard-view-single', function( e ) {
		e.preventDefault();
		e.stopPropagation();

		var $btn    = $( this );
		var id      = $btn.data( 'id' );
		var canView = $btn.data( 'canView' );

		if ( ! isPro && ! canView ) {
			showProUpsell( $btn );
			return;
		}

		if ( ! id ) {
			return;
		}

		$btn.prop( 'disabled', true );

		$.post(
			turboGuardAdmin.ajaxUrl,
			{ action: 'turbo_guard_view_file', nonce: turboGuardAdmin.nonce, result_id: id },
			function( r ) {
				$btn.prop( 'disabled', false );
				if ( r.success && r.data ) {
					openModal( r.data );
				} else {
					alert( r.data ? r.data.message : ( strings.viewFile + ' failed.' ) );
				}
			}
		).fail( function() {
			$btn.prop( 'disabled', false );
			alert( 'Server error while loading the file.' );
		} );
	} );

	// Populate and open the file-view modal.
	function openModal( data ) {
		$( '#turbo-guard-view-modal-title' ).text( data.file_path || '' );
		$( '#turbo-guard-view-modal-meta' )
			.empty()
			.append( $( '<span>' ).addClass( 'turbo-guard-badge turbo-guard-badge-' + ( data.severity || 'info' ) ).text( ( data.severity || 'info' ).charAt( 0 ).toUpperCase() + ( data.severity || 'info' ).slice( 1 ) ) )
			.append( ' ' )
			.append( $( '<span>' ).text( data.threat_name || '' ) );

		var $code = $( '#turbo-guard-view-modal-code' );
		$code.text( data.content || '' );
		if ( data.truncated ) {
			$code.append( '\n\n\u2026 (truncated \u2014 showing first 8 KB)' );
		}

		$modal.show();
	}

	// Show a small upsell tooltip near the clicked View button (free users).
	function showProUpsell( $btn ) {
		// Remove any existing tooltip.
		$( '.turbo-guard-pro-tooltip' ).remove();

		var msg  = strings.viewProMessage || 'Viewing file contents is a Pro feature. Upgrade to inspect every threat in detail and clean unlimited files.';
		var link = $( '<a>' )
			.attr( 'href', proUrl )
			.attr( 'target', '_blank' )
			.attr( 'rel', 'noopener noreferrer' )
			.text( strings.upgradeNow || 'Upgrade Now' );

		var $tip = $( '<div>' ).addClass( 'turbo-guard-pro-tooltip' );
		$tip.append( $( '<strong>' ).text( strings.viewProTitle || 'Turbo Guard Pro' ) );
		$tip.append( $( '<p>' ).text( msg ) );
		$tip.append( link );

		$btn.after( $tip );

		// Close on outside click.
		$( document ).one( 'click', function() {
			$tip.remove();
		} );

		// Prevent the outside-click handler from firing immediately.
		$tip.on( 'click', function( e ) {
			e.stopPropagation();
		} );
	}
} );
