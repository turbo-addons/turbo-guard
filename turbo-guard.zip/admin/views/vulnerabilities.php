<?php
/**
 * Vulnerabilities Page Template.
 *
 * @package TurboGuard
 * @since 1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$turbo_guard_results    = Turbo_Guard_Vuln_Scanner::get_cached_results();
$turbo_guard_is_pro  = turbo_guard_is_pro();
?>

<div class="wrap turbo-guard-vulnerabilities">

	<!-- Page Header -->
	<div class="turbo-guard-page-header">
		<div class="turbo-guard-page-header-left">
			<div class="turbo-guard-page-header-icon">
				<span class="dashicons dashicons-warning"></span>
			</div>
			<div>
				<h1><?php esc_html_e( 'Vulnerability Scanner', 'turbo-guard' ); ?></h1>
				<p><?php esc_html_e( 'Check plugins, themes &amp; WordPress core for known CVEs', 'turbo-guard' ); ?></p>
			</div>
		</div>
		<?php if ( $turbo_guard_results ) : ?>
			<span class="turbo-guard-header-badge">
				<?php
				printf(
					/* translators: %s: time ago */
					esc_html__( 'Last scan: %s ago', 'turbo-guard' ),
					esc_html( human_time_diff( strtotime( $turbo_guard_results['scanned_at'] ), current_time( 'timestamp' ) ) )
				);
				?>
			</span>
		<?php endif; ?>
	</div>

	<!-- Scan control -->
	<div class="turbo-guard-card">
		<div class="turbo-guard-scan-hero">
			<div class="turbo-guard-scan-intro">
				<h2><?php esc_html_e( 'Vulnerability Check', 'turbo-guard' ); ?></h2>
				<p>
					<?php esc_html_e( 'Checks all installed plugins and themes against the WPScan vulnerability database. Add a free WPScan API key in Settings for more detailed results.', 'turbo-guard' ); ?>
				</p>
			</div>
			<button id="turbo-guard-run-vuln-scan" class="button button-primary button-large">
				<span class="dashicons dashicons-search"></span>
				<?php esc_html_e( 'Run Vulnerability Scan', 'turbo-guard' ); ?>
			</button>
		</div>
		<div id="turbo-guard-vuln-scanning" style="display:none;margin-top:14px;padding-top:14px;border-top:1px solid #f3f4f6;">
			<span class="spinner is-active" style="float:none;vertical-align:middle;margin-right:6px;"></span>
			<strong><?php esc_html_e( 'Scanning installed plugins and themes…', 'turbo-guard' ); ?></strong>
		</div>
		<div id="turbo-guard-vuln-notice" class="turbo-guard-notice" style="display:none;"></div>
	</div>

	<?php if ( $turbo_guard_results ) : ?>

		<?php if ( ! $turbo_guard_is_pro ) : ?>
			<div class="notice notice-info inline" style="margin:12px 0 0;">
				<p>
					<?php
					printf(
						wp_kses(
							/* translators: %s: pro URL */
							__( 'You\'re viewing basic vulnerability results. <a href="%s" target="_blank" rel="noopener noreferrer">Upgrade to Turbo Guard Pro</a> to unlock CVE IDs, fix versions, detailed advisories, auto-scheduled scans and email alerts.', 'turbo-guard' ),
							array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
						),
						esc_url( turbo_guard_pro_url() )
					);
					?>
				</p>
			</div>
		<?php endif; ?>

		<!-- Summary cards -->
		<div class="turbo-guard-stats-grid" style="grid-template-columns:repeat(3,1fr);">
			<div class="turbo-guard-card turbo-guard-stat-card <?php echo $turbo_guard_results['total'] > 0 ? 'tg-threat' : ''; ?>" style="padding:18px 20px;">
				<h3><?php esc_html_e( 'Total Vulnerabilities', 'turbo-guard' ); ?></h3>
				<div class="turbo-guard-stat-value <?php echo $turbo_guard_results['total'] > 0 ? 'tg-red' : 'tg-green'; ?>">
					<?php echo esc_html( $turbo_guard_results['total'] ); ?>
				</div>
				<p class="turbo-guard-stat-label"><?php esc_html_e( 'Across plugins, themes &amp; core', 'turbo-guard' ); ?></p>
			</div>
			<div class="turbo-guard-card" style="padding:18px 20px;">
				<h3><?php esc_html_e( 'Vulnerable Plugins', 'turbo-guard' ); ?></h3>
				<div class="turbo-guard-stat-value <?php echo count( $turbo_guard_results['plugins'] ) > 0 ? 'tg-red' : ''; ?>">
					<?php echo esc_html( count( $turbo_guard_results['plugins'] ) ); ?>
				</div>
				<p class="turbo-guard-stat-label"><?php esc_html_e( 'Plugins with known CVEs', 'turbo-guard' ); ?></p>
			</div>
			<div class="turbo-guard-card" style="padding:18px 20px;">
				<h3><?php esc_html_e( 'Vulnerable Themes', 'turbo-guard' ); ?></h3>
				<div class="turbo-guard-stat-value <?php echo count( $turbo_guard_results['themes'] ) > 0 ? 'tg-red' : ''; ?>">
					<?php echo esc_html( count( $turbo_guard_results['themes'] ) ); ?>
				</div>
				<p class="turbo-guard-stat-label"><?php esc_html_e( 'Themes with known CVEs', 'turbo-guard' ); ?></p>
			</div>
		</div>

		<?php if ( ! empty( $turbo_guard_results['wordpress'] ) ) : ?>
			<!-- WordPress core vulnerabilities -->
			<div class="turbo-guard-card" style="border-left:4px solid #dc2626;">
				<h2 style="color:#dc2626;">
					<span class="dashicons dashicons-warning" style="vertical-align:middle;margin-right:4px;"></span>
					<?php esc_html_e( 'WordPress Core Vulnerabilities', 'turbo-guard' ); ?>
				</h2>
				<p class="description"><?php esc_html_e( 'Update WordPress immediately to resolve these issues.', 'turbo-guard' ); ?></p>
				<?php turbo_guard_render_vuln_table( $turbo_guard_results['wordpress'] ); ?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $turbo_guard_results['plugins'] ) ) : ?>
			<div class="turbo-guard-card">
				<h2><?php esc_html_e( 'Plugin Vulnerabilities', 'turbo-guard' ); ?></h2>
				<?php foreach ( $turbo_guard_results['plugins'] as $turbo_guard_plugin ) : ?>
					<div class="turbo-guard-vuln-item">
						<div class="turbo-guard-vuln-plugin-header">
							<strong><?php echo esc_html( $turbo_guard_plugin['name'] ); ?></strong>
							<span class="description">v<?php echo esc_html( $turbo_guard_plugin['version'] ); ?></span>
							<span class="turbo-guard-badge turbo-guard-badge-critical" style="margin-left:8px;">
								<?php
								printf(
									/* translators: %d: count */
									esc_html( _n( '%d issue', '%d issues', $turbo_guard_plugin['count'], 'turbo-guard' ) ),
									esc_html( $turbo_guard_plugin['count'] )
								);
								?>
							</span>
						</div>
						<?php turbo_guard_render_vuln_table( $turbo_guard_plugin['vulnerabilities'] ); ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $turbo_guard_results['themes'] ) ) : ?>
			<div class="turbo-guard-card">
				<h2><?php esc_html_e( 'Theme Vulnerabilities', 'turbo-guard' ); ?></h2>
				<?php foreach ( $turbo_guard_results['themes'] as $turbo_guard_theme ) : ?>
					<div class="turbo-guard-vuln-item">
						<div class="turbo-guard-vuln-plugin-header">
							<strong><?php echo esc_html( $turbo_guard_theme['name'] ); ?></strong>
							<span class="description">v<?php echo esc_html( $turbo_guard_theme['version'] ); ?></span>
							<span class="turbo-guard-badge turbo-guard-badge-high" style="margin-left:8px;">
								<?php
								printf(
									/* translators: %d: count */
									esc_html( _n( '%d issue', '%d issues', $turbo_guard_theme['count'], 'turbo-guard' ) ),
									esc_html( $turbo_guard_theme['count'] )
								);
								?>
							</span>
						</div>
						<?php turbo_guard_render_vuln_table( $turbo_guard_theme['vulnerabilities'] ); ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( 0 === $turbo_guard_results['total'] ) : ?>
			<div class="turbo-guard-card">
				<div class="turbo-guard-no-threats">
					<span class="dashicons dashicons-yes-alt"></span>
					<p><?php esc_html_e( 'No known vulnerabilities found — all plugins and themes are clean!', 'turbo-guard' ); ?></p>
				</div>
			</div>
		<?php endif; ?>

	<?php else : ?>

		<div class="turbo-guard-card">
			<div class="turbo-guard-no-scan">
				<span class="dashicons dashicons-shield"></span>
				<p><?php esc_html_e( 'No vulnerability scan has been run yet. Click "Run Vulnerability Scan" to start.', 'turbo-guard' ); ?></p>
			</div>
		</div>

	<?php endif; ?>

</div><!-- /.wrap -->

<?php
/**
 * Render a vulnerability table.
 *
 * @param array $vulns List of normalised vulnerability arrays.
 */
function turbo_guard_render_vuln_table( $vulns ) {
	if ( empty( $vulns ) ) {
		return;
	}

	$is_pro = turbo_guard_is_pro();
	?>
	<table class="widefat turbo-guard-results-table" style="margin-top:10px;">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Vulnerability', 'turbo-guard' ); ?></th>
				<th style="width:90px;"><?php esc_html_e( 'Type', 'turbo-guard' ); ?></th>
				<th style="width:90px;"><?php esc_html_e( 'Severity', 'turbo-guard' ); ?></th>
				<th style="width:110px;"><?php esc_html_e( 'Fixed In', 'turbo-guard' ); ?></th>
				<th style="width:60px;"><?php esc_html_e( 'CVE', 'turbo-guard' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $vulns as $v ) : ?>
				<tr>
					<td>
						<strong style="font-size:12px;"><?php echo esc_html( $v['title'] ); ?></strong>
						<?php if ( $is_pro && $v['url'] ) : ?>
							<br><a href="<?php echo esc_url( $v['url'] ); ?>" target="_blank" rel="noopener noreferrer" style="font-size:11px;">
								<?php esc_html_e( 'Details →', 'turbo-guard' ); ?>
							</a>
						<?php endif; ?>
					</td>
					<td style="font-size:11px;"><?php echo esc_html( $v['type'] ); ?></td>
					<td>
						<span class="turbo-guard-badge turbo-guard-badge-<?php echo esc_attr( $v['severity'] ); ?>">
							<?php echo esc_html( ucfirst( $v['severity'] ) ); ?>
						</span>
					</td>
					<td style="font-size:12px;">
						<?php if ( $is_pro ) : ?>
							<?php echo $v['fixed_in'] ? esc_html( $v['fixed_in'] ) : '<span style="color:#dc2626;">No fix</span>'; ?>
						<?php else : ?>
							<a href="<?php echo esc_url( turbo_guard_pro_url() ); ?>" target="_blank" rel="noopener noreferrer" class="button button-small" style="font-size:11px;"><?php esc_html_e( 'Pro', 'turbo-guard' ); ?></a>
						<?php endif; ?>
					</td>
					<td style="font-size:11px;">
						<?php if ( $is_pro ) : ?>
							<?php if ( ! empty( $v['cve'] ) ) : ?>
								<?php foreach ( $v['cve'] as $cve ) : ?>
									<?php
									printf(
										'<a href="https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-%s" target="_blank" rel="noopener noreferrer">CVE-%s</a> ',
										esc_attr( $cve ),
										esc_html( $cve )
									);
									?>
								<?php endforeach; ?>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						<?php else : ?>
							<a href="<?php echo esc_url( turbo_guard_pro_url() ); ?>" target="_blank" rel="noopener noreferrer" class="button button-small" style="font-size:11px;"><?php esc_html_e( 'Pro', 'turbo-guard' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}
// Use function directly in template for simplicity.
add_action( 'turbo_guard_render_vuln_table', 'turbo_guard_render_vuln_table' );
